Estelle Bayer
CS 332
This seg-faults whenever it tries to switch processes. I can not for the life of me
figure out why this should be the case. Print statements at the end of the proc_switch
function are printed, but print statements immediately after the function returns
are not. This class was incredibly challenging for me, in a way that led to significant
growth in my capabilities and knowledge base, but my project performance definitely
reflects how out of my comfort zone it put me. 
